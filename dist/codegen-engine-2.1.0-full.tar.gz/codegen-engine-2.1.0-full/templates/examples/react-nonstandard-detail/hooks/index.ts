export { useDetailData } from './useDetailData';
