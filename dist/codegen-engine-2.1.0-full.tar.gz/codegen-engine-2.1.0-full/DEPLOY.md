# 部署说明（离线版）

此版本已包含所有依赖，无需联网安装。

## 快速部署

```bash
# 1. 解压
tar -xzvf codegen-engine-*-full.tar.gz
cd codegen-engine-*-full

# 2. 添加执行权限（首次部署需要）
chmod +x start.sh

# 3. 启动服务
./start.sh

# 4. 验证
curl http://localhost:7331/health
```

## 环境要求

- Node.js v16+（必须预装）
- PM2（脚本会自动全局安装，需要 npm 可用）

如果 PM2 也无法安装，可直接运行：
```bash
node src/server-http.js
```

## 服务管理

- **启动**: `./start.sh`
- **停止**: `./stop.sh` 或 `pm2 stop codegen-engine`
- **重启**: `pm2 restart codegen-engine`
- **日志**: `pm2 logs codegen-engine`

## 端口配置

默认端口 7331，可通过环境变量修改：
```bash
PORT=8080 ./start.sh
```
